// Detección de base para soportar despliegue desde root
const isRoot = !window.location.pathname.includes('/www-entregables/') && !window.location.pathname.includes('e01.html') && !window.location.pathname.includes('e02.html');
const pathBase = isRoot ? 'www-entregables/' : '';

document.addEventListener('DOMContentLoaded', () => {
    renderSidebar();
    renderFooter();

    // Trigger de impresión automática para el portal
    if (window.location.search.includes('print=true')) {
        setTimeout(() => {
            window.print();
        }, 800);
    }
});

function renderSidebar() {
    const sidebarRoot = document.getElementById('sidebar-root');
    if (!sidebarRoot) return;

    // Determinar si estamos en consignas.html para personalizar el ToC
    const isConsignas = window.location.pathname.includes('consignas.html');

    // Contenido del ToC variable
    let tocContent = '';
    if (isConsignas) {
        tocContent = `
            <div class="toc-container">
                <p class="toc-header">Documento</p>
                <ul class="toc-list">
                    <li><a href="${pathBase}assets/docs/consigna_tp.pdf" download class="toc-link">↓ Descargar PDF</a></li>
                </ul>
            </div>
        `;
    } else {
        tocContent = `
            <div class="toc-container">
                <p class="toc-header">En esta página</p>
                <ul class="toc-list" id="tocList">
                    <!-- Se generará dinámicamente por navigation.js -->
                </ul>
            </div>
        `;
    }

    // HTML del Sidebar
    const sidebarHTML = `
        <aside class="sidebar no-print">
            <div class="sidebar-version" style="position: absolute; top: 10px; right: 10px; font-size: 0.65rem; background: var(--accent-color); color: white; padding: 2px 6px; border-radius: 4px; font-weight: bold; opacity: 0.8;">v1.0</div>
            <div class="sidebar-profile">
                <div class="avatar-container">
                    <video src="${pathBase}assets/img/avatar/dtic-GEMA_01.mp4" class="sidebar-avatar" autoplay muted playsinline></video>
                </div>
                <div class="profile-name">dtic-GEMA</div>
                <div class="profile-title">Entidad de Asistencia Virtual</div>
            </div>
            <nav class="sidebar-nav">
                <a href="${isRoot ? 'index.html' : 'index.html'}" class="sidebar-nav-item">Portal Principal</a>
                <a href="${pathBase}consignas.html" class="sidebar-nav-item">Consignas TP Final</a>
                <a href="${pathBase}e01.html" class="sidebar-nav-item">Entregable E01</a>
                <a href="${pathBase}e02.html" class="sidebar-nav-item">Entregable E02</a>
            </nav>
            ${tocContent}
        </aside>
    `;

    sidebarRoot.innerHTML = sidebarHTML;

    // Marcar activo después de insertar
    highlightActiveLink();
}

function renderFooter() {
    const footerRoot = document.getElementById('footer-root');
    if (!footerRoot) return;

    const currentYear = new Date().getFullYear(); // Dinámico por si acaso, o fijo Enero 2026

    // Estandarización del Footer
    footerRoot.innerHTML = `
        <footer>
            <p>dtic-GEMA v1.0 | Lic. Ricardo Monla | DiploIA TP Final | Enero 2026</p>
        </footer>
    `;
}

function highlightActiveLink() {
    const currentPath = window.location.pathname;
    // Si es raíz (/) o index.html, machear index.html
    // Simplificación: buscar href que esté contenido en el path

    const navItems = document.querySelectorAll('.sidebar-nav-item');
    navItems.forEach(item => {
        const href = item.getAttribute('href');
        // Lógica básica de active
        if (currentPath.includes(href) || (currentPath.endsWith('/') && href === 'index.html')) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
}
