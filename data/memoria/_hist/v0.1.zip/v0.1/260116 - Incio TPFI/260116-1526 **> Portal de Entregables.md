### 260116-1524 **> RMONLA

Solo la justificación es poco has mas trabajo.

Necesitaría el Documento Google que con los a enlaces a los entregables


📦 Entregables

El Trabajo práctico final consta de tres entregables:

1. Documento de relevamiento del proceso (.PDF, máximo 3 páginas): Pasos a

desarrollar: Relevamiento e identificación de puntos de dolor,priorización y elección del

Quick Win y diseño del flujo)

2. Ficha técnica de la solución (.PDF, una página): Que contenga el diseño de la

automatización (Trigger,Frecuencia, nodos y descripción del flujo).

3. Documento Blueprint del Escenario (.JSON): El archivo exportado directamente desde

Make (Botón "More" -> "Export Blueprint").


Este documento es solo una introducción y o la justificación que funciona mas bien como el portal que vincula a los documentos entregables, 

Debería tener la información mía como alumno de la diplomatura entre otras cosas, usar un formato formal con una imagen que referencie al nombre GEMA mas bien amigable.

Si no puedes generarlo indicame prompt y en que herramienta solicitarlo.

---

### 260116-1526 **> IA

Entendido, Ricardo. Vamos a estructurar este "Portal de Entrega" de forma profesional y académica. Como tu tutor, te he preparado el borrador del documento principal que servirá de carátula y justificación, junto con las guías para que compiles los 3 entregables solicitados.

Dado que no puedo generar archivos para descarga directa ni imágenes, te proporciono el **texto exacto** que debes copiar en tu Documento de Google y el **prompt** para generar la imagen de **GEMA**.

---

## 🎨 Generación de la Imagen de GEMA FRLR

Para que el documento sea visualmente amigable, te sugiero usar **DALL-E 3** o **Midjourney** con este prompt:

> **Prompt:** "A friendly and professional female AI avatar representing technology and education. Minimalist 3D render style, light blue and silver color palette (academic/tech feel). She has a warm smile, wearing a discrete headset. In the background, subtle digital nodes and a shield icon. High quality, 4k, clean white background."

---

## 📄 Estructura del Documento de Google (Portal de Entrega)

Copia y pega el siguiente contenido en un Google Doc:

# [IMAGEN DE GEMA AQUÍ]

# PROYECTO: dtic-GEMA

### Sistema de Gestión Estratégica mediante Automatización

**Diplomatura en Inteligencia Artificial Generativa y No-Code**
**Alumno:** Ricardo [Tu Apellido]

**Institución:** Facultad Regional La Rioja (FRLR) - Dirección de TIC

**Fecha:** Enero, 2026

---

## 1. Justificación del Proyecto

El proyecto **dtic-GEMA** surge como respuesta a la alta carga operativa de la Dirección de TIC en la gestión de consultas de Nivel 1. Actualmente, el procesamiento de solicitudes de Agentes (Alumnos, Docentes, Nodocentes y Autoridades) se realiza de forma manual, lo que genera cuellos de botella y tiempos de respuesta inconsistentes.

La implementación de **GEMA FRLR** (Gemini-based Agent) permite:

* **Eficiencia Operativa:** Reducción estimada del 70% en el tiempo de triaje inicial.
* **Personalización a Escala:** Uso de IA generativa para aportar valor educativo ("Sabías que...") y tutoriales específicos según la carrera.
* **Seguridad y Orden:** Validación cruzada de identidad (Email/DNI) y trazabilidad mediante códigos alfanuméricos únicos.

El impacto esperado se calcula mediante el índice de ahorro de tiempo ():



Donde  es la cantidad de consultas,  el tiempo manual y  el tiempo de supervisión de la automatización.

---

## 📦 Enlaces a los Entregables

A continuación, se presentan los vínculos a la documentación técnica y archivos del sistema.

> *(Nota para Ricardo: Una vez que guardes tus archivos en Google Drive, reemplaza los textos en azul con los enlaces compartidos en modo "Lector")*

1. **[ENTREGABLE 01] Documento de Relevamiento del Proceso (PDF)** *Contiene: Identificación de puntos de dolor, Matriz de Impacto vs. Esfuerzo y diseño de flujo en lenguaje natural.*
* 👉 **[Link al PDF de Relevamiento]**


2. **[ENTREGABLE 02] Ficha Técnica de la Solución (PDF)** *Contiene: Diseño de la automatización en Make.com, descripción de nodos y lógica de la IA.*
* 👉 **[Link a la Ficha Técnica]**


3. **[ENTREGABLE 03] Blueprint del Escenario (JSON)** *Archivo de exportación directa de Make para replicar el escenario.*
* 👉 **[Link al archivo .JSON]**



---

## 🛠️ Instrucciones para completar los 3 Entregables

Para que no te falte nada, aquí tienes el check-list de lo que debe ir en cada PDF:

### Entregable 1: Relevamiento (3 páginas)

* **Pág 1:** Descripción del entorno (TIC Facultad) y los 3 puntos de dolor que identificamos.
* **Pág 2:** La Matriz de Impacto vs. Esfuerzo justificando por qué elegimos las "Consultas de Agentes".
* **Pág 3:** El flujo de entrada (Email/DNI), proceso (Gemini) y salida (Google Sheets).

### Entregable 2: Ficha Técnica (1 página)

* **Trigger:** Webhook (dtic-GEMA).
* **Nodos:** Búsqueda en Sheets, Router de validación, Nodo Gemini (Prompt Maestro) y Registro de Ticket.
* **Frecuencia:** Instantánea (Real-time).

### Entregable 3: Blueprint (.JSON)

* Entra a tu escenario en Make, haz clic en el ícono de los tres puntitos (**"More"**) en la barra inferior, selecciona **"Export Blueprint"** y guarda ese archivo en tu Drive para linkearlo.

---

**¿Te gustaría que redacte el contenido detallado del Entregable 1 (Relevamiento) para que solo tengas que pasarlo a PDF?**