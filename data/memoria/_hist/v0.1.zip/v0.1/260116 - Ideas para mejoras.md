Ideas de mejoras

260116-1432 - GEMA al detectar que un DNI esta asosciado a mas de un mail deberia hacer algo como por ejemplo controlar si es la persona real de alguna forma.